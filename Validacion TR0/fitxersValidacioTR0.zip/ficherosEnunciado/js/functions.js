
document.addEventListener("DOMContentLoaded",function() {
    //EL TEU CODI AQUI
   
})
